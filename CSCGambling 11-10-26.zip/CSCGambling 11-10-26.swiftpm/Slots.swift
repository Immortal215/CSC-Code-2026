import SwiftUI

struct SlotsView: View {
    @AppStorage("money") var money : Double = 100
    
    @State var slotMachine : [Int] = [0, 1, 2]
    @State var moneyToBet : Double = 0
    @State var pot : Double = 0 
    
    var canBet : Bool {
        if moneyToBet != 0 && moneyToBet <= money {
            return true 
        } else {
            return false
        }
    }
    
    var body : some View {
        Text("SlotsView")
        
        Text("Total Money: $\(money, specifier: "%.2f")")
        
        if pot > 0 {
            Text("Money Bet: \(pot, specifier: "%.2f")")
        }
        
        HStack {
            ForEach(slotMachine.indices, id: \.self) { index in 
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                    
                    Text(numToEmoji(num: slotMachine[index]))
                        .foregroundStyle(.black)
                        .font(.largeTitle)
                }
                .frame(width: 100, height: 100)
            }
        }
        
        if pot == 0 { 
            Text("Money to bet: \(moneyToBet, specifier: "%.2f")")
            
            Slider(value: $moneyToBet, in: 0...money)
                .padding()    
            }
        
        if canBet {
            Button {
                if moneyToBet <= money {
                    money -= moneyToBet 
                    pot += moneyToBet
                    moneyToBet = 0 
                }
            } label: {
                Text("Bet Money")
                
            }
            .buttonStyle(.borderedProminent)
        }
        
        if pot > 0 {
            Button {
                for i in 0...2 {
                    slotMachine[i] = Int.random(in: 0...2)
                }
            
            } label: {
                Text("Play")
            }
            .buttonStyle(.borderedProminent)
        }
            
        
    }
    func numToEmoji(num : Int) -> String {
        if num == 0 {
            return "🍒"
        } 
        
        if num == 1 {
            return "🥑"
        } else {
            return "🐒"
        }
    }
}

