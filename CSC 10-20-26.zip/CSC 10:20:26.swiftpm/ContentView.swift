import SwiftUI

struct ContentView: View {
    @State var money = 100
    @State var text = "Coin Flip"
    @State var moneyToBet : Int = 0
    @State var pot = 0 
    @State var headsChosen : Bool?
    
    var body: some View {
        VStack {
            Text("Total Money: \(money)")
            
            if pot > 0 {
                Text("Money Bet: \(pot)")
            }
            
            ZStack {
                Circle()
                    .frame(width: 100, height: 100)
                
                Text(text)
                    .foregroundStyle(.black)
            }
            .onTapGesture {
                var result = Int.random(in: 0...1)
                
                if result == 0 {
                    text = "Tails"
                } else {
                    text = "Heads"
                }
            }
            
            TextField("Money to bet", value: $moneyToBet, format: .number)
                .textFieldStyle(.roundedBorder)
            
            Button {
                if moneyToBet <= money {
                    money -= moneyToBet 
                    pot += moneyToBet
                    moneyToBet = 0 
                }
            } label: {
                Text("Bet Money")
                    
            }
            .buttonStyle(.borderedProminent)
          
            HStack { 
                Button {
                    headsChosen = true     
                } label: {
                    Text("Heads")
                        .padding()
                        .background {
                            RoundedRectangle(cornerRadius:8)
                                .stroke(headsChosen == true ? .blue : .gray, lineWidth: 1)
                        }
                }
                
                Button {
                    headsChosen = false 
                } label: {
                    Text("Tails")
                        .padding()
                        .background {
                            RoundedRectangle(cornerRadius:8)
                                .stroke(headsChosen == false ? .blue : .gray, lineWidth: 1)
                        }
                }
            }
        }
        .padding() 
        
    }
}
