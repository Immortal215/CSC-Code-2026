import SwiftUI

struct ContentView : View {
    var body : some View {
        NavigationStack {
            HStack { 
                NavigationLink {
                    CoinView()     
                } label : {
                    Text("Coin View")    
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 12).stroke(lineWidth: 2))
                    
                }
                
                NavigationLink {
                    SlotsView()                    
                } label : {
                    Text("Slots View")
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 12).stroke(lineWidth: 2))
                }
            }
        }
    }
}
