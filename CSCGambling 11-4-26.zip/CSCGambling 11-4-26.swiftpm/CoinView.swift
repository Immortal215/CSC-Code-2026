import SwiftUI

struct CoinView: View {
    @AppStorage("money") var money : Double = 100
    @State var text = "Coin Flip"
    @State var moneyToBet : Double = 0
    @State var pot : Double = 0 
    @State var headsChosen : Bool?
    
    var canBet : Bool {
           if headsChosen != nil && moneyToBet != 0 && moneyToBet <= money {
               return true 
           } else {
               return false
           }
    }
    
    var body: some View {
        VStack(spacing: 8) {
            Text("Total Money: $\(money, specifier: "%.2f")")
            
            if pot > 0 {
                Text("Money Bet: \(pot, specifier: "%.2f")")
                
                Text("Flip Chosen: \(headsChosen! ? "Heads" : "Tails")")
            }
            
            ZStack {
                Circle()
                    .frame(width: 100, height: 100)
                
                Text(text)
                    .foregroundStyle(.black)
            }
            .onTapGesture {
                if headsChosen != nil {
                    var result = Int.random(in: 0...1)
                    
                    if result == 0 {
                        text = "Tails"
                    } else {
                        text = "Heads"
                    }
                    
                    if (headsChosen! == true && result == 1) || (headsChosen! == false && result == 0) {
                        money += 2 * pot
                        pot = 0
                        headsChosen = nil 
                    } else {
                        pot = 0 
                        headsChosen = nil 
                    }
                }
            }
            
            Divider()
            
            
            if pot == 0 { 
                Text("Money to bet: \(moneyToBet, specifier: "%.2f")")
                Slider(value: $moneyToBet, in: 0...money)
                
                HStack { 
                    Button {
                        headsChosen = true     
                    } label: {
                        Text("Heads")
                            .padding()
                            .background {
                                RoundedRectangle(cornerRadius:8)
                                    .stroke(headsChosen == true ? .blue : .gray, lineWidth: 1)
                            }
                    }
                    
                    Button {
                        headsChosen = false 
                    } label: {
                        Text("Tails")
                            .padding()
                            .background {
                                RoundedRectangle(cornerRadius:8)
                                    .stroke(headsChosen == false ? .blue : .gray, lineWidth: 1)
                            }
                    }
                    
                    
                }
                
                if canBet {
                    Button {
                        if moneyToBet <= money {
                            money -= moneyToBet 
                            pot += moneyToBet
                            moneyToBet = 0 
                        }
                    } label: {
                        Text("Bet Money")
                        
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
        }
        .padding() 
        
    }
}
