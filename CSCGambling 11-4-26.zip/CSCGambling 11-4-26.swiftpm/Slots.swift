import SwiftUI

struct SlotsView: View {
    
    
    var body : some View {
        Text("SlotsView")
    }
}
